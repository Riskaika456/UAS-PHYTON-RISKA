print("BARIS")
print("KOLOM")
print("====TASK 3 MODUL 2====")
print("===SEDRI SELLA JUMENI===")
angka1=2
a=angka1+4+\
    7+\
    5
print(a)
print("====TASK 3 MODUL 2====")
print("===SEDRI SELLA JUMENI===")
kutipan1='belajar python'
kutipan2="belajar pythondasar"
kutipan3=("""belajar python siang malam""")

print(kutipan1)
print(kutipan2)
print(kutipan3)
print("====TASK 3 MODUL 2====")
print("===SEDRI SELLA JUMENI===")
#KOMENTAR
print("ini adalah komentar")#untuk komentar anda bisa menambahkan tanda (#)diawal kaliamat
#dua pernyataan dalam satu baris
print ("titik koma");print("titik titik koma")
print("====TASK 3 MODUL 2====")
print("===SEDRI SELLA JUMENI===")
#TIPE DATA
# tipe data int
umur = 25
print("Umur saya adalah", umur)

# tipe data string
nama = "John Doe"
print("Nama saya adalah", nama)

# tipe data float
berat_badan = 65.5
print("Berat badan saya adalah", berat_badan, "kg")

# tipe data boolean
benar = True
salah = False
print("Apakah benar?", benar)
print("Apakah salah?", salah)

# tipe data list
buah = ["apel", "jeruk", "mangga"]
print("Buah yang saya suka adalah", buah)

# tipe data kompleks
angka_kompleks = 3 + 4j
print("Angka kompleks adalah", angka_kompleks)

# Tipe data tuple
hari = ("Senin", "Selasa", "Rabu", "Kamis", "Jumat", "Sabtu", "Minggu")
print("Hari-hari dalam seminggu adalah:", hari)

# Tipe data set
angka = {1, 2, 3, 4, 5}
print("Set angka:", angka)
angka2 = {3, 4, 5, 6, 7}
print("Set angka2:", angka2)
# Intersection
print("Intersection:", angka.intersection(angka2))
# Union
print("Union:", angka.union(angka2))
# Difference
print("Difference:", angka.difference(angka2))

# Tipe data dictionary
mahasiswa = {"nama": "John Doe", "nim": "123456", "prodi": "Teknik Informatika"}
print("Data mahasiswa:", mahasiswa)
print("Nama mahasiswa:", mahasiswa["nama"])
print("NIM mahasiswa:", mahasiswa["nim"])
print("Program Studi mahasiswa:", mahasiswa["prodi"])


print("====TASK 3 MODUL 2====")
print("===SEDRI SELLA JUMENI===")
#Operator & Ekspresi
#1.Operator Aritmatika
a=10
b=3
c=a/b
d=a**b
e=a//b
print("Hasil :",c)
print("Pangkat :",d)
print("Hasil :",e)
#2.Operator perbandingan
a=10
b=5

c= a < b
print(c)

c=a > b
print(c)

c= a==b
print(c)

c= a!=b
print(c)
#Operator penugasan
print("===Operator Penugasan=====")
#Penugasan
print("=ontoh 1 ")
a= 12
b=2

a+=b
print(a)

a=12
b=2
a-=b
print(a)
print (" contoh 2")
x=5
x-=3 #x=x-3
print(x)

#Operator Logika
#1. Operatoe and
print("====Operator logika=====")
x=10
print(x>5 and x< 5)

#2. Operator or
a=True
b=False
print(a or b)

#Operator Not
c=True
d=not c 
print("not",c,"=",d)

#Operator bitwise
print ("===Operator bitwise==")
a=2
b=3

c=a|b 
print(c)

c=a & b 
print (c)

c=a^b 
print (c)

c=a<<b 
print(c)

c=a>>b 
print (c)
#Operator Identitas
print ("==Operator identitas==")
x="Pyhton"
y=20
z="Pyhton"

print (x is y )
print (x is z )

print (x is not y)
print (x is not z)

print(type(x) is str)
print (type(z) is int )

#Operator Keanggotaan 
print ("==Operator keanggotaan 1===")
kata=" hari ini belajar pyhton"
#1. Operator in
print ("hari" in kata )
print ("siang" in kata)
#2. Operator not in
print("belajar" not in kata)
print ("pyhton" not in kata)
print ("")
print ("==Operator keanggotaan 2===")
kata=5,6, "operasi"
#1. Operator in
print (5 in kata )
print (6 in kata)   
#2. Operator not in
print(6 not in kata)
print ("operasi" not in kata)



 
